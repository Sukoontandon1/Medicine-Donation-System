<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <!-- Required meta tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="CSS/bootstrapmy.css">
    <!-- Optional JavaScript; choose one of the two! -->
    <script src="JS/Jquery.js"></script>
    <script src="JS/Bootstrapmy.bundle.min.js"></script>
    <title>Document</title>
    <script>
        $(document).ready(function() {
            $("#uid").keyup(function() {
                var uid = $("#uid").val();
                var call = "ajax-chk-uid-edit-med.php?uid=" + uid;
                $.get(call, function(response) {
                    $("#chkuid").html(response);
                });
            });
        });

    </script>
</head>

<body style="background-color: #f0f0f0;">
    <?php
    include_once("header.php");
    ?>
    <?php
session_start();
if(isset($_SESSION["active_user"])==false) 
    header("location:index.php");
?>
    <div style="width: 100px;height: 30px;background-color: green;cursor: pointer;border-radius: 5px;text-align: center;margin-top: 10px;margin-left: 1400px;">
        <a href="logout.php" style="color: white;text-decoration: none;" title="Logout">Logout</a>
    </div>
    <div style="width: 80%;font-size: 40px;height: 80px;margin-left: 152px;cursor: pointer;border-radius: 5px;border: 1px green solid;color: green;margin-top: 30px;">
        <center>
            <label type="" readonly value="<?php echo $_SESSION['active_user']?>" style="float:left;margin-left:10px;text-align: center;margin-top: 5px;">
                <i class="fa fa-user" aria-hidden="true"></i>&nbsp;<?php echo "Welcome ".$_SESSION['active_user']?>
            </label>
        </center>
    </div>
    <form method="get" action="ajax-update-edit-med.php">
        <div id="editmed" tabindex="-1" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog">
                <div class="modal-content  mb-5" style="width: 700px;margin-left: -100px;float: left;">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title" id="exampleModalLabel">Edit Quantity Of Medicine</h5>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">User ID&nbsp;&nbsp;</label>
                            <input type="text" class="form-control" name="uid" id="uid" required>
                            <div id="" class="form-text">
                                <span id="chkuid" class="form-text"></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Medicine Name</label>
                            <input type="text" class="form-control" name="medname" id="medname" required>
                            <div id="" class="form-text">
                                <span id="" class="form-text"></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Quantity</label>
                            <input type="number_format" class="form-control" name="qty" id="qty" required>
                            <div id="" class="form-text">
                                <span id="" class="form-text"></span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer mb-3">
                        <input type="submit" id="updatebtn" class="btn btn-success" style="color: white;width: 150px;" value="Update Details" name="btn">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </div>
                    <center>
                        <div class="mb-3"><span id="saved"></span></div>
                    </center>
                </div>
            </div>
        </div>
    </form>
</body>

</html>
