<html>

<head>
    <meta charset="UTF-8">
    <!-- Required meta tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="CSS/bootstrapmy.css">
    <!-- Optional JavaScript; choose one of the two! -->
    <script src="JS/Jquery.js"></script>
    <script src="JS/Bootstrapmy.bundle.min.js"></script>
    <title>Document</title>
</head>

<body>
    <div class="row bg-success">
        <div class="col-md-12">
            <h3 class="text-white" style="padding: 5px;text-align: center;">www.medassist.com</h3>
        </div>
    </div>
</body>

</html>
