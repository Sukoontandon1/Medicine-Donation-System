<?php
    session_start();
    include_once("mysql-connection.php");
    $email=$_GET["email1"];
    $pwd=$_GET["pwd1"];
    $_SESSION["active_user"]=$email;
    $query="select * from users where email='$email' and pwd='$pwd'";
    $table=mysqli_query($dbcon,$query);
	$count=mysqli_num_rows($table);
	if($count==0)
		echo "Invalid ID or Password";
    else
    {
        while($row=mysqli_fetch_array($table))
        {
        echo $row["category"];
        }
    }
?>
