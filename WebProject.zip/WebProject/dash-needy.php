<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <!-- Required meta tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="CSS/bootstrapmy.css">
    <!-- Optional JavaScript; choose one of the two! -->
    <script src="JS/Jquery.js"></script>
    <script src="JS/Bootstrapmy.bundle.min.js"></script>
    <title>Document</title>
</head>

<body style="background-color: #f0f0f0;">
    <?php
    include_once("header.php");
    ?>
    <?php
session_start();
if(isset($_SESSION["active_user"])==false) 
    header("location:index.php");
?>
    <div style="width: 100px;height: 30px;background-color: green;cursor: pointer;border-radius: 5px;text-align: center;margin-top: 10px;margin-left: 1400px;">
        <a href="logout.php" style="color: white;text-decoration: none;" title="Logout">Logout</a>
    </div>
    <div style="width: 80%;font-size: 40px;height: 80px;margin-left: 152px;cursor: pointer;border-radius: 5px;border: 1px green solid;color: green;margin-top: 30px;">
        <center>
            <label type="" readonly value="<?php echo $_SESSION['active_user']?>" style="float:left;margin-left:10px;text-align: center;margin-top: 5px;">
                <i class="fa fa-user" aria-hidden="true"></i>&nbsp;<?php echo "Welcome ".$_SESSION['active_user']?>
            </label>
        </center>
    </div>
    <div class="card" style="width: 18rem;margin-top: 100px;margin-left: 440px;float: left;">
        <div class="card-body">
            <div style="height: 143px;padding: 5px;text-align: center;">
                <img src="Pics/userlogin.png" width="100" height="100">
            </div>
            <div class="bg-success" style="border-radius: 5px;height: 30px;">
                <center><a href="profile-editor-needy.php" class="card-link" style="text-decoration: none;color: white;padding-top: 10px;">Profile</a></center>
            </div>
        </div>
    </div>
    <div class="card" style="width: 18rem;margin-top: 100px;margin-left: 60px;float: left">
        <div class="card-body">
            <div style="height: 143px;padding: 5px;text-align: center;">
                <img src="Pics/medicines.jpg" width="150" height="120">
            </div>
            <div class="bg-success" style="border-radius: 5px;height: 30px;">
                <center><a href="find-medicines.php" class="card-link" style="text-decoration: none;color: white;padding-top: 10px;">Find Medicines</a></center>
            </div>
        </div>
    </div>
</body>

</html>
