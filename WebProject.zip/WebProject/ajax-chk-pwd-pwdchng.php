<?php
include_once("mysql-connection.php");
$pwd=$_GET["pwd"];
$uid=$_GET["uid"];
$query1="select * from users where pwd='$pwd' and email='$uid'";
$table=mysqli_query($dbcon,$query1);
$count1=mysqli_num_rows($table);
if($count1==1)
    echo "";
else 
    echo "Wrong Password";
?>
