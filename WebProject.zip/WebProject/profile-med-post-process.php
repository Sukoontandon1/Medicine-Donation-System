<?php
include_once("mysql-connection.php");
    $uid=$_POST["uid"];
    $medname=$_POST["medname"];
    $company=$_POST["company"];
    $doexp=$_POST["doexp"];
    $unit=$_POST["unit"];
    $qty=$_POST["qty"];
    $powerr=$_POST["powerr"];
    $pic1tmpname=$_FILES["pic1"]["tmp_name"];
    $pic1name=$_FILES["pic1"]["name"];
    $pic2tmpname=$_FILES["pic2"]["tmp_name"];
    $pic2name=$_FILES["pic2"]["name"];
    move_uploaded_file($pic1tmpname,"uploads/".$pic1name);
    move_uploaded_file($pic2tmpname,"uploads/".$pic2name);
    $query1="select * from profiles where uid='$uid'";
    $table=mysqli_query($dbcon,$query1);
    while ($row=mysqli_fetch_array($table))
    {
        $city=$row['city'];
    }
    $query="insert into medicines(uid, medname, company, doexp, unit, qty, powerr, pic1, pic2,city) values('$uid','$medname','$company','$doexp','$unit','$qty','$powerr','$pic1name','$pic2name','$city')";
    mysqli_query($dbcon,$query);
    $msg=mysqli_error($dbcon);
    if (mysqli_error($dbcon)=="")
        header("location: response.php?uid=".$uid."&msg=Medicine Posted Successfully");
    else 
        header("location: response1.php?uid=".$uid."&msg=".mysqli_error($dbcon));
?>
