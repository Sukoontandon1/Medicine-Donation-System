<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <script src="JS/Jquery.js"></script>
    <script src="js/angular.min.js"></script>
    <script>
        var mymodule = angular.module("mykuchbhi", []);
        mymodule.controller("mycontroller", function($http, $scope) {
            $scope.jsonArray = [];
            $scope.doFetchAll = function() {
                var uid = angular.element('#uid').val();
                var url = "json-admin-med-controller.php?uid=" + uid;
                $http.get(url).then(fxOk, fxNotok);

                function fxOk(response) {
                    $scope.xx = response.data;
                }

                function fxNotok(error) {
                    alert(error.data);
                }
            }
            $scope.doDelete = function(rid) {
                if (confirm("Are You Sure?") == false)
                    return;
                else {
                    var url = "delete-med-controller.php?rid=" + rid;
                    $http.get(url).then(fxOk, fxNotok);

                    function fxOk(response) {
                        $scope.doFetchAll();
                    }

                    function fxNotok(error) {
                        alert(error.data);
                    }
                }
            }
        });

    </script>

    <style>
        th {
            color: white;
            font: arial;
        }

    </style>
</head>

<body ng-app="mykuchbhi" ng-controller="mycontroller" ng-init="doFetchAll();" style="background-color: #f0f0f0;">
    <center><br><br>
        <br><br>
        <table border="1" rules="all" width="100%">
            <tr height="40" bgcolor="green">
                <th align="center">Delete</th>
                <th align="center">Serial Number</th>
                <th align="center">User ID</th>
                <th align="center">Medicine Name</th>
                <th align="center">Company</th>
                <th align="center">Date Of Expiry</th>
                <th align="center">Type Of Medicine</th>
                <th align="center">Quantity</th>
                <th align="center">Weightage</th>
                <th align="center">Front Image</th>
                <th align="center">Back Image</th>
            </tr>
            <tr ng-repeat="x in xx">
                <td align="center">
                    <img src="pics/cross.jpg" alt="" width="20" style="margin-top: 4px;cursor: pointer;" height="20" ng-click="doDelete(x.rid);">
                </td>
                <td align="center">{{$index+1}}</td>
                <td align="center">{{x.uid}}</td>
                <td align="center">{{x.medname}}</td>
                <td align="center">{{x.company}}</td>
                <td align="center">{{x.doexp}}</td>
                <td align="center">{{x.unit}}</td>
                <td align="center">{{x.qty}}</td>
                <td align="center">{{x.powerr}}</td>
                <th align="center">
                    <img src="uploads/{{x.pic1}}" alt="" style="margin-top: 4px;" width="40" height="40">
                </th>
                <th align="center">
                    <img src="uploads/{{x.pic2}}" alt="" style="margin-top: 4px;" width="40" height="40">
                </th>
            </tr>
        </table>
    </center>
</body>

</html>
