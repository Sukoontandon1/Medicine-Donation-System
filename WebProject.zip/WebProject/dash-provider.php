<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <!-- Required meta tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="CSS/bootstrapmy.css">
    <!-- Optional JavaScript; choose one of the two! -->
    <script src="JS/Jquery.js"></script>
    <script src="JS/Bootstrapmy.bundle.min.js"></script>
    <title>Document</title>
    <script>
        $(document).ready(function() {
            $("#uid").blur(function() {
                var uid = $("#uid").val();
                var call = "ajax-chk-uid-pwdchng.php?uid=" + uid;
                $.get(call, function(response) {
                    $("#chkuid").html(response);
                });
            });
            $("#pwd").blur(function() {
                var pwd = $("#pwd").val();
                var uid = $("#uid").val();
                var call = "ajax-chk-pwd-pwdchng.php?pwd=" + pwd + "&uid=" + uid;
                $.get(call, function(response) {
                    $("#chkpwd").html(response);
                });
            });
        });

        function dosubmit(event) {
            if (document.querySelector("#chkpwd").innerHTML != "" || document.querySelector("#chkuid").innerHTML != "")
                event.preventDefault();
        }

    </script>
</head>

<body style="background-color: #f0f0f0;">
    <?php
include_once("header.php");
?>
    <?php
session_start();
if(isset($_SESSION["active_user"])==false) 
    header("location:index.php");
?>
    <div style="width: 100px;height: 30px;background-color: green;cursor: pointer;border-radius: 5px;text-align: center;margin-top: 10px;margin-left: 1400px;">
        <a href="logout.php" style="color: white;text-decoration: none;" title="Logout">Logout</a>
    </div>
    <div style="width: 80%;font-size: 40px;height: 80px;margin-left: 152px;cursor: pointer;border-radius: 5px;border: 1px green solid;color: green;margin-top: 30px;">
        <center>
            <label type="" readonly value="<?php echo $_SESSION['active_user']?>" style="float:left;margin-left:10px;text-align: center;margin-top: 5px;">
                <i class="fa fa-user" aria-hidden="true"></i>&nbsp;<?php echo "Welcome ".$_SESSION['active_user']?>
            </label>
        </center>
    </div>
    <div class="card" style="width: 18rem;margin-top: 100px;margin-left: 100px;float: left">
        <div class="card-body">
            <div style="height: 143px;padding: 5px;text-align: center;">
                <img src="Pics/userlogin.png" width="100" height="100">
            </div>
            <div class="bg-success" style="border-radius: 5px;height: 30px;cursor: pointer;">
                <center><a href="profile-editor.php" class="card-link" style="text-decoration: none;color: white;padding-top: 10px;">Profile</a></center>
            </div>
        </div>
    </div>
    <div class="card" style="width: 18rem;margin-top: 100px;margin-left: 60px;float: left">
        <div class="card-body">
            <div style="height: 143px;padding: 5px;text-align: center;">
                <img src="Pics/settings-icon.png" width="100" height="100">
            </div>
            <div class="bg-success" style="border-radius: 5px;height: 30px;">
                <center>
                    <div class="card-link text-white" data-bs-target="#pwdchng" data-bs-toggle="modal" style="cursor: pointer;padding-top: 1.5px;">Settings</div>
                </center>
            </div>
        </div>
    </div>
    <div class="card" style="width: 18rem;margin-top: 100px;margin-left: 60px;float: left">
        <div class="card-body">
            <div style="height: 143px;padding: 5px;text-align: center;">
                <img src="Pics/medicines.jpg" width="160" height="120">
            </div>
            <div class="bg-success" style="border-radius: 5px;height: 30px;cursor: pointer;">
                <center><a href="provider-med-post.php" class="card-link" style="text-decoration: none;color: white;padding-top: 10px;">Post Medicines</a></center>
            </div>
        </div>
    </div>
    <div class="card" style="width: 18rem;margin-top: 100px;margin-left: 60px;float: left">
        <div class="card-body">
            <div style="height: 143px;padding: 5px;text-align: center;">
                <img src="Pics/medlist.png" width="160" height="120">
            </div>
            <div class="bg-success" style="border-radius: 5px;height: 30px;cursor: pointer;">
                <center><a href="med-manager.php" class="card-link" style="text-decoration: none;color: white;padding-top: 10px;">Medicine Manager</a></center>
            </div>
        </div>
    </div>
    <form action="ajax-update-pwd.php" onsubmit="dosubmit(event);" method="post">
        <div class="modal fade" id="pwdchng" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title" id="exampleModalLabel">Change Password</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Email ID</label>
                            <input type="email" class="form-control" name="uid" id="uid" required aria-describedby="emailHelp">
                            <div id="" class="form-text">
                                <span id="chkuid" class="form-text"></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Old Password</label>
                            <input type="password" class="form-control" name="pwd" required id="pwd">
                            <div id="" class="form-text">
                                <span id="chkpwd" class="form-text"></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password" class="form-control" required name="newpwd" id="newpwd">
                            <div id="" class="form-text">
                                <span id="" class="form-text"></span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer mb-3">
                        <button type="button" class="btn btn-success" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success" value="Update" id="updatebtn" name="updatebtn">Update</button>
                    </div>
                    <center>
                        <div class="mb-3"><span id="saved"></span></div>
                    </center>
                </div>
            </div>
        </div>
    </form>
</body>

</html>
