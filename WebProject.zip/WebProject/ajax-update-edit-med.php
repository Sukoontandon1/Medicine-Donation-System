<?php
include_once("mysql-connection.php");
    $uid=$_GET["uid"];
    $medname=$_GET["medname"];
    $qty=$_GET["qty"];
    $query="update medicines set qty='$qty' where uid='$uid' and medname='$medname'";
    mysqli_query($dbcon,$query);
    $count=mysqli_affected_rows($dbcon);
    if (mysqli_error($dbcon)=="")
    {
        if($count==1)
        {
            header("location: response.php?uid=".$uid."&msg=Quantity Updated Successfully");
        }
        else
            header("location: response-med-post.php?uid=".$uid."&msg=No Medicine Found With This Name");
    }
    else
        echo mysqli_error($dbcon);
?>
