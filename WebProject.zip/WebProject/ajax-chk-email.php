<?php
    include_once("mysql-connection.php");
    $email=$_GET["email"];
    $query="select * from users where email='$email'";
	$table=mysqli_query($dbcon,$query);
	$count=mysqli_num_rows($table);
	if($count==0)
		echo "Available";
	else
		echo "Already Occupied";
?>
