<?php
include_once("mysql-connection.php");
$uid=$_GET["uid"];
$query="select * from profiles where uid='$uid'";
$data=mysqli_query($dbcon,$query);
$count=mysqli_num_rows($data);
if($count==1)
    echo "User ID Already Exists";
else 
    echo "";
?>