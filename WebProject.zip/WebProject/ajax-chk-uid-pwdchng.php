<?php
include_once("mysql-connection.php");
$uid=$_GET["uid"];
$query="select * from users where email='$uid'";
$data=mysqli_query($dbcon,$query);
$count=mysqli_num_rows($data);
if($count==1)
    echo "";
else 
    echo "Email ID Does Not Exist";
?>