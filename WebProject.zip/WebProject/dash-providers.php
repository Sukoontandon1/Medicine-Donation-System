<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <script src="JS/Jquery.js"></script>
    <script src="js/angular.min.js"></script>
    <script>
        var mymodule = angular.module("mykuchbhi", []);
        mymodule.controller("mycontroller", function($http, $scope) {
            $scope.jsonArray = [];
            $scope.doFetchAll = function() {
                var uid = angular.element('#uid').val();
                var url = "json-dash-providers.php?uid=" + uid;
                $http.get(url).then(fxOk, fxNotok);

                function fxOk(response) {
                    $scope.xx = response.data;
                }

                function fxNotok(error) {
                    alert(error.data);
                }
            }
        });

    </script>

    <style>
        th {
            color: white;
            font: arial;
        }

        td {
            padding: 10px;
        }

    </style>
</head>

<body ng-app="mykuchbhi" ng-controller="mycontroller" ng-init="doFetchAll();" style="background-color: #f0f0f0;">
    <center><br><br>
        <br><br>
        <table border="1" rules="all" width="100%">
            <tr height="40" bgcolor="green">
                <th align="center">Serial Number</th>
                <th align="center">User ID</th>
                <th align="center">Name</th>
                <th align="center">Contact</th>
                <th align="center">Address</th>
                <th align="center">City</th>
            </tr>
            <tr ng-repeat="x in xx">
                <td align="center">{{$index+1}}</td>
                <td align="center">{{x.uid}}</td>
                <td align="center">{{x.name}}</td>
                <td align="center">{{x.contact}}</td>
                <td align="center">{{x.address}}</td>
                <td align="center">{{x.city}}</td>
            </tr>
        </table>
    </center>
</body>

</html>
