<?php
    $btn=$_POST["updatebtn"];
    include_once("mysql-connection.php");
    $uid=$_POST["uid"];
    $pwd=$_POST["pwd"];
    $newpwd=$_POST["newpwd"];
    $query="update users set pwd='$newpwd' where email='$uid'";
    mysqli_query($dbcon,$query);
    $count=mysqli_affected_rows($dbcon);
    if (mysqli_error($dbcon)==""){
        if($count==1)
        header("location: response.php?uid=".$uid."&msg=Password Changed Successfully");
        else
        header("location: response.php?uid=".$uid."&msg=Invalid ID");
    }
    else
        echo mysqli_error($dbcon);
?>
