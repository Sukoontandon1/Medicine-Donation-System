<?php
include_once("mysql-connection.php");
$med=$_GET["med"];
$city=$_GET["city"];
$query="select * from medicines where medname='$med' and city='$city'";
$table=mysqli_query($dbcon,$query);
$ary=array();
while($row=mysqli_fetch_array($table))
{
	$ary[]=$row;
}
echo json_encode($ary);
?>
