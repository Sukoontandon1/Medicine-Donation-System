<?php
$btn=$_POST["btn"];
include_once("mysql-connection.php");
if($btn=="Save Details"){  
    $uid=$_POST["uid"];
    $name=$_POST["name"];
    $contact=$_POST["contact"];
    $address=$_POST["address"];
    $city=$_POST["city"];
    $idtype=$_POST["idtype"];
    $idnumber=$_POST["idnumber"];
    $picpathtmpname=$_FILES["picpath"]["tmp_name"];
    $picpathname=$_FILES["picpath"]["name"];
    $idpathtmpname=$_FILES["idpath"]["tmp_name"];
    $idpathname=$_FILES["idpath"]["name"];
    move_uploaded_file($picpathtmpname,"uploads/".$picpathname);
    move_uploaded_file($idpathtmpname,"uploads/".$idpathname);
    $query="insert into profiles values('$uid','$name','$contact','$address','$city','$picpathname','$idpathname','$idtype','$idnumber')";
    mysqli_query($dbcon,$query);
    $msg=mysqli_error($dbcon);
    if (mysqli_error($dbcon)=="")
        header("location: response.php?uid=".$uid."&msg=Records Saved Successfully");
    else 
        header("location: response1.php?uid=".$uid."&msg=User ID Already Exists, Please Choose Another User ID");
}
else if($btn=="Update Details"){
    $uid=$_POST["uid"];
    $name=$_POST["name"];
    $contact=$_POST["contact"];
    $address=$_POST["address"];
    $city=$_POST["city"];
    $idtype=$_POST["idtype"];
    $idnumber=$_POST["idnumber"];
    $picpathtmpname=$_FILES["picpath"]["tmp_name"];
    $picpathname=$_FILES["picpath"]["name"];
    $idpathtmpname=$_FILES["idpath"]["tmp_name"];
    $idpathname=$_FILES["idpath"]["name"]; 
    move_uploaded_file($picpathtmpname,"uploads/".$picpathname);
    move_uploaded_file($idpathtmpname,"uploads/".$idpathname);
    $query="update profiles set contact='$contact', name='$name', address='$address', city='$city', picpath='$picpathname', idpath='$idpathname', idtype='$idtype', idnumber='$idnumber' where uid='$uid'";
    mysqli_query($dbcon,$query);
    $count=mysqli_affected_rows($dbcon);
    if (mysqli_error($dbcon)==""){
        if($count==1)
        header("location: response.php?uid=".$uid."&msg=Records Updated Successfully");
        else
        header("location: response1.php?uid=".$uid."&msg=Invalid ID Or No Records Changed");
    }
    else
        echo mysqli_error($dbcon);
}
?>
