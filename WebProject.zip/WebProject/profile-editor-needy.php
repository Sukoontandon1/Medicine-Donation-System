<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <!-- Required meta tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="CSS/bootstrapmy.css">
    <!-- Optional JavaScript; choose one of the two! -->
    <script src="JS/Jquery.js"></script>
    <script src="JS/Bootstrapmy.bundle.min.js"></script>
    <title>Document</title>
    <script>
        $(document).ready(function() {
            $("#fetchbtn").click(function() {
                var uid = $("#uid").val();
                var url = "json-fetch-record-needy.php?uid=" + uid;
                $.getJSON(url, function(response) {
                    if (response == "")
                        $("#saved").html("User ID Does Not Exist");
                    else
                        $("#saved").html("");
                    $("#name").val(response[0].name);
                    $("#contact").val(response[0].contact);
                    $("#address").val(response[0].address);
                    $("#city").val(response[0].city);
                });
            });
            $("#uid").blur(function() {
                var uid = $("#uid").val();
                var call = "ajax-chk-uid-needy.php?uid=" + uid;
                $.get(call, function(response) {
                    $("#chkuid").html(response);
                });
            });
        });

    </script>
</head>

<body style="background-color: #f0f0f0;">
    <?php
    include_once("header.php");
    ?>
    <?php
session_start();
if(isset($_SESSION["active_user"])==false) 
    header("location:index.php");
?>
    <div style="width: 100px;height: 30px;background-color: green;cursor: pointer;border-radius: 5px;text-align: center;margin-top: 10px;margin-left: 1400px;">
        <a href="logout.php" style="color: white;text-decoration: none;" title="Logout">Logout</a>
    </div>
    <div style="width: 80%;font-size: 40px;height: 80px;margin-left: 152px;cursor: pointer;border-radius: 5px;border: 1px green solid;color: green;margin-top: 30px;">
        <center>
            <label type="" readonly value="<?php echo $_SESSION['active_user']?>" style="float:left;margin-left:10px;text-align: center;margin-top: 5px;">
                <i class="fa fa-user" aria-hidden="true"></i>&nbsp;<?php echo "Welcome ".$_SESSION['active_user']?>
            </label>
        </center>
    </div>
    <form method="post" action="profile-editor-process-needy.php" enctype="multipart/form-data">
        <div id="profilepage" tabindex="-1" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog">
                <div class="modal-content  mb-5" style="width: 700px;margin-left: -100px;float: left;">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title" id="exampleModalLabel">Profile Page</h5>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">User ID&nbsp;&nbsp;</label>
                            <input type="text" class="form-control" name="uid" id="uid" required>
                            <div id="" class="form-text">
                                <span id="chkuid" class="form-text"></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" id="name" required>
                            <div id="" class="form-text">
                                <span id="" class="form-text"></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Contact Number</label>
                            <input type="number_format" class="form-control" name="contact" id="contact" required>
                            <div id="" class="form-text">
                                <span id="" class="form-text"></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Home Address</label>
                            <input type="text" class="form-control" name="address" id="address" required>
                            <div id="" class="form-text">
                                <span id="" class="form-text"></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">City</label>
                            <input list="city_name" class="form-control" name="city" id="city" required>
                            <datalist id="city_name">
                                <option value="Chandigarh">
                                <option value="New Delhi">
                                <option value="Mumbai">
                                <option value="Bangalore">
                                <option value="Chennai">
                                <option value="Pune">
                                <option value="Hyderabad">
                                <option value="Kolkata">
                            </datalist>
                            <div id="" class="form-text">
                                <span id="" class="form-text"></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ID Proof</label>
                            <input type="file" class="form-control" name="idpath" id="idpath" required>
                            <div id="" class="form-text">
                                <span id="" class="form-text"></span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer mb-3">
                        <input type="submit" class="btn btn-success" style="color: white;width: 150px;" value="Save Details" name="btn">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <button type="button" class="btn btn-success" style="color: white;width: 150px;" id="fetchbtn">Fetch Details</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" class="btn btn-success" style="color: white;width: 150px;" value="Update Details" name="btn">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </div>
                    <center>
                        <div class="mb-3"><span id="saved"></span></div>
                    </center>
                </div>
            </div>
        </div>
    </form>
</body>

</html>
