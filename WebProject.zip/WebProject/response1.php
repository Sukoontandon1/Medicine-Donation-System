<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>

<body style="background-color: #f0f0f0;">
    <?php
    include_once("header.php");
    ?>
    <center>
        <h2 style="color: green;">
            Welcome <?php echo $_GET["uid"]; ?> <br>
        </h2>
        <hr style="color: green;">
        <p>
        <h3 style="color: green;">
            <?php echo $_GET["msg"]; ?>
        </h3>
        <h4>
            <a style="color: green;" href="profile-editor.php">
                Go Back To Profile Page
            </a>
        </h4>
        </p>
    </center>
</body>

</html>
