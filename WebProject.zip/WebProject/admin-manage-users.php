<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <script src="JS/Jquery.js"></script>
    <script src="js/angular.min.js">
    </script>
    <script>
        var mymodule = angular.module("mykuchbhi", []);
        mymodule.controller("mycontroller", function($http, $scope) {
            $scope.jsonArray = [];
            $scope.doFetchAll = function() {
                var url = "json-user-control.php";
                $http.get(url).then(fxOk, fxNotok);

                function fxOk(response) {
                    $scope.xx = response.data;
                }

                function fxNotok(error) {
                    alert(error.data);
                }
            }
            $scope.doBlock = function(email) {
                if (confirm("Are You Sure?") == false)
                    return;
                else {
                    var url = "block-user-control.php?email=" + email;
                    $http.get(url).then(fxOk, fxNotok);

                    function fxOk(response) {
                        $scope.doFetchAll();
                    }

                    function fxNotok(error) {
                        alert(error.data);
                    }
                }
            }
            $scope.doResume = function(email) {
                if (confirm("Are You Sure?") == false)
                    return;
                else {
                    var url = "resume-user-control.php?email=" + email;
                    $http.get(url).then(fxOk, fxNotok);

                    function fxOk(response) {
                        $scope.doFetchAll();
                    }

                    function fxNotok(error) {
                        alert(error.data);
                    }
                }
            }
        });

    </script>

    <style>
        th {
            color: white;
            font: arial;
        }

    </style>
</head>

<body ng-app="mykuchbhi" ng-controller="mycontroller" ng-init="doFetchAll();" style="background-color: #f0f0f0;">
    <center><br><br><br><br>
        <table border="1" rules="all" width="100%">
            <tr height="40" bgcolor="green">
                <th align="center">Serial Number</th>
                <th align="center">Email</th>
                <th align="center">Password</th>
                <th align="center">Mobile</th>
                <th align="center">Category</th>
                <th align="center">Date Of Signup</th>
                <th align="center">Block User</th>
                <th align="center">Resume User</th>
            </tr>
            <tr ng-repeat="x in xx">
                <td align="center">{{$index+1}}</td>
                <td align="center">{{x.email}}</td>
                <td align="center">{{x.pwd}}</td>
                <td align="center">{{x.mobile}}</td>
                <td align="center">{{x.category}}</td>
                <td align="center">{{x.dos}}</td>
                <th align="center">
                    <img ng-if="x.status==1" src="Pics/block.jpg" alt="" style="margin-top: 4px;cursor: pointer;" width="40" height="40" ng-click="doBlock(x.email);">
                </th>
                <th align="center">
                    <img ng-if="x.status==0" src="Pics/resume.webp.png" alt="" style="margin-top: 4px;cursor: pointer;" width="60" height="40" ng-click="doResume(x.email);">
                </th>
            </tr>
        </table>
    </center>
</body>

</html>
