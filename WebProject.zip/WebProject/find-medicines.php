<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <!-- Required meta tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="CSS/bootstrapmy.css">
    <!-- Optional JavaScript; choose one of the two! -->
    <script src="JS/Jquery.js"></script>
    <script src="JS/Bootstrapmy.bundle.min.js"></script>
    <title>Document</title>
    <script src="JS/angular.min.js"></script>
    <script>
        var mymodule = angular.module("mykuchbhi", []);
        mymodule.controller("mycontroller", function($http, $scope) {
            $scope.xx = [];
            $scope.city1 = [];
            $scope.doFetchAll = function() {
                var url = "json-fetch-medname.php";
                $http.get(url).then(fxOk, fxNotok);

                function fxOk(response) {
                    $scope.xx = response.data;
                }

                function fxNotok(error) {
                    alert(error.data);
                }
            }
            $scope.doFetchAllCard = function() {
                var url = "json-fetch-med-details.php?med=" + $scope.med + "&city=" + $scope.city;
                $http.get(url).then(fxOk, fxNotok);

                function fxOk(response) {
                    $scope.yy = response.data;
                }

                function fxNotok(error) {
                    alert(error.data);
                }
            }
            $scope.doFetchCity = function() {
                var url = "json-fetch-city.php?med=" + $scope.med;
                $http.get(url).then(fxOk, fxNotok);

                function fxOk(response) {
                    $scope.city1 = response.data;
                }

                function fxNotok(error) {
                    alert(error.data);
                }
            }
            $scope.showmodal = function(uid, medname, rid) {
                $scope.uid = uid;
                var url = "find-show-modal.php?uid=" + uid + "&medname=" + medname + "&rid=" + rid;
                $http.get(url).then(fxOk, fxNotok);

                function fxOk(response) {
                    $scope.medd = response.data;
                }

                function fxNotok(error) {
                    alert(error.data);
                }
            }
            $scope.showcontact = function() {
                var url = "find-show-contact.php?uid=" + $scope.uid;
                $http.get(url).then(fxOk, fxNotok);

                function fxOk(response) {
                    $scope.contact = response.data;
                }

                function fxNotok(error) {
                    alert(error.data);
                }
            }
        });

    </script>
</head>

<body ng-app="mykuchbhi" ng-controller="mycontroller" ng-init="doFetchAll();" style="background-color: #f0f0f0;">
    <?php
    include_once("header.php");
    ?>
    <?php
session_start();
if(isset($_SESSION["active_user"])==false) 
    header("location:index.php");
?>
    <div style="width: 100px;height: 30px;background-color: green;cursor: pointer;border-radius: 5px;text-align: center;margin-top: 10px;margin-left: 1400px;">
        <a href="logout.php" style="color: white;text-decoration: none;" title="Logout">Logout</a>
    </div>
    <div style="width: 80%;font-size: 40px;height: 80px;margin-left: 152px;cursor: pointer;border-radius: 5px;border: 1px green solid;color: green;margin-top: 30px;">
        <center>
            <label type="" readonly value="<?php echo $_SESSION['active_user']?>" style="float:left;margin-left:10px;text-align: center;margin-top: 5px;">
                <i class="fa fa-user" aria-hidden="true"></i>&nbsp;<?php echo "Welcome ".$_SESSION['active_user']?>
            </label>
        </center>
    </div>
    <center><br><br>
        <div class="row form-group">
            <span style="margin-right: 5px;padding: 20px;font-family: arial;">Select Medicine
                <select id="meds" style="margin-left: 20px;margin-right: 20px;width: 300px; height: 30px;border-radius: 5px;" ng-change="doFetchCity()" ng-model="med">
                    <option value="" selected="selected">Select Medicine</option>
                    <option value="{{obj.medname}}" ng-repeat="obj in xx">{{obj.medname}}</option>
                </select>
                Select City
                <select style="margin-left: 20px;width: 300px; height: 30px;border-radius: 5px;" ng-model="city">
                    <option value="" selected="selected">Select City</option>
                    <option value="{{obj.city}}" ng-repeat="obj in city1">
                        {{obj.city}}
                    </option>
                </select>
            </span><input type="button" value="Find Providers" class="btn btn-success" style="width: 150px;margin: auto;margin-top: 30px;" ng-click="doFetchAllCard();">
        </div>
        <div class="row mt-5">
            <div class="col-md-4 mb-5" ng-repeat="x in yy">
                <div class="card" style="width: 18rem;">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <img src="Uploads/{{x.pic1}}" style="border-radius: 10px;" width="100" height="100">
                        </li>
                        <li class="list-group-item">
                            <b>Medicine Name:</b> {{x.medname}}
                        </li>
                        <li class="list-group-item">
                            <b>Company:</b> {{x.company}}
                        </li>
                        <li class="list-group-item">
                            <b>Quantity:</b> {{x.qty}}
                        </li>
                        <li class="list-group-item">
                            <b>Date Of Expiry:</b> {{x.doexp}}
                        </li>
                        <li class="list-group-item">
                            <input type="button" value="Details" data-bs-toggle="modal" ng-click="showmodal(x.uid,x.medname,x.rid);" data-bs-target="#Datacheck" class="btn btn-success">
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </center>
    <div class="modal fade" id="Datacheck" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title" id="exampleModalLabel">Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form ng-repeat="x in medd">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label"><b>Medicine Name:</b></label>
                            <input type="text" class="form-control" id="med" name="med" readonly aria-describedby="emailHelp" value="{{x.medname}}">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label"><b>Type:</b></label>
                            <input type="text" class="form-control" id="qty" min="1" name="qty" readonly aria-describedby="emailHelp" value="{{x.unit}}">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label"><b>Weight (Potency):</b></label>
                            <input type="text" class="form-control" id="qty" min="1" name="qty" readonly aria-describedby="emailHelp" value="{{x.powerr}}">
                        </div>
                        <div class="row">
                            <div class="col-md-6" style="border-radius: 10px;">
                                <label for="exampleInputPassword1" class="form-label"><b>Images:</b></label>
                                <center><img src="uploads/{{x.pic1}}" style="height:150px;width:180px;border:0.5px black solid;" alt=""></center>
                            </div>
                            <div class="col-md-6" style="margin-top:2.0rem;border-radius: 10px;">
                                <center><img src="uploads/{{x.pic2}}" style="height:150px;width:180px;border:0.5px black solid;" alt=""></center>
                            </div>
                        </div>
                        <div class="modal-footer mt-3">
                            <input type="button" class="btn btn-success" id="update" name="update" style="margin: auto;" value="Contact Details" ng-click="showcontact();">
                        </div>
                        <div class="col-md-10" ng-repeat="x in contact">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item"><b>Name:-</b> {{x.name}}</li>
                                <li class="list-group-item"><b>Address:-</b> {{x.address}}&comma; {{x.city}}
                                </li>
                                <li class="list-group-item"><b>Mobile Number:-</b> {{x.contact}}</li>
                            </ul>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
