<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <script src="JS/Jquery.js"></script>
    <script src="js/angular.min.js">
    </script>
    <script>
        var mymodule = angular.module("mykuchbhi", []);
        mymodule.controller("mycontroller", function($http, $scope) {
            $scope.jsonArray = [];
            $scope.doFetchAll = function() {
                var uid = angular.element('#uid').val();
                var url = "json-fetch-med-all.php?uid=" + uid;
                $http.get(url).then(fxOk, fxNotok);

                function fxOk(response) {
                    $scope.xx = response.data;
                }

                function fxNotok(error) {
                    alert(error.data);
                }
            }
            $scope.doDelete = function(rid) {
                if (confirm("Are You Sure?") == false)
                    return;
                else {
                    var url = "delete-med-json.php?rid=" + rid;
                    $http.get(url).then(fxOk, fxNotok);

                    function fxOk(response) {
                        $scope.doFetchAll();
                    }

                    function fxNotok(error) {
                        alert(error.data);
                    }
                }
            }
        });
        $(document).ready(function() {
            $("#uid").keyup(function() {
                var uid = $("#uid").val();
                var call = "ajax-chk-uid-med-manager.php?uid=" + uid;
                $.get(call, function(response) {
                    $("#chkuid").html(response);
                });
            });
        });

    </script>

    <style>
        th {
            color: white;
            font: arial;
        }

    </style>
</head>

<body ng-app="mykuchbhi" ng-controller="mycontroller" style="background-color: #f0f0f0;">
    <?php
session_start();
if(isset($_SESSION["active_user"])==false) 
    header("location:index.php");
?>
    <div style="width: 100px;height: 30px;background-color: green;cursor: pointer;border-radius: 5px;text-align: center;margin-top: 10px;margin-left: 1400px;font-family: arial;">
        <a href="logout.php" style="color: white;text-decoration: none;font-family: arial;margin-top: 5px;float: left;margin-left: 25px;" title="Logout">Logout</a>
    </div>
    <div style="width: 80%;font-size: 40px;height: 80px;margin-left: 152px;cursor: pointer;border-radius: 5px;border: 1px green solid;color: green;margin-top: 30px;">
        <center>
            <label type="" readonly value="<?php echo $_SESSION['active_user']?>" style="float:left;text-align: center;margin-top: 15px;font-family: arial;margin-left: 20px;">
                <i class="fa fa-user" aria-hidden="true"></i>&nbsp;<?php echo "Welcome ".$_SESSION['active_user']?>
            </label>
        </center>
    </div>
    <center><br><br>
        <div class="row form-group"><span style="margin-right: 5px;padding: 20px;font-family: arial;">User ID:<input id="uid" style="margin-left: 20px;width: 300px; height: 30px;border-radius: 5px;" type="text"><input type="button" value="View All Posted Medicines" ng-click="doFetchAll();" style="margin-left: 70px;font-family: arial;font-size: 15px;color: white;background-color: green;padding: 7px;border-radius: 5px;cursor: pointer;" id="medpost"></span></div>
        <div id="" class="form-text">
            <br>
            <span id="chkuid" class="form-text" style="margin-right: 392px;margin-top: 20px;font-family: arial;"></span>
        </div><br><br>
        <table border="1" rules="all" width="100%">
            <tr height="40" bgcolor="green">
                <th align="center">Delete</th>
                <th align="center">Edit</th>
                <th align="center">Serial Number</th>
                <th align="center">User ID</th>
                <th align="center">Medicine Name</th>
                <th align="center">Company</th>
                <th align="center">Date Of Expiry</th>
                <th align="center">Type Of Medicine</th>
                <th align="center">Quantity</th>
                <th align="center">Weightage</th>
                <th align="center">Front Image</th>
                <th align="center">Back Image</th>
            </tr>
            <tr ng-repeat="x in xx">
                <td align="center">
                    <img src="pics/cross.jpg" alt="" width="20" style="margin-top: 4px;cursor: pointer;" height="20" ng-click="doDelete(x.rid);">
                </td>
                <td align="center">
                    <img src="pics/edit.png" alt="" width="20" style="margin-top: 4px;cursor: pointer;" height="20" onclick="window.open('edit-med.php','_self');">
                </td>
                <td align="center">{{$index+1}}</td>
                <td align="center">{{x.uid}}</td>
                <td align="center">{{x.medname}}</td>
                <td align="center">{{x.company}}</td>
                <td align="center">{{x.doexp}}</td>
                <td align="center">{{x.unit}}</td>
                <td align="center">{{x.qty}}</td>
                <td align="center">{{x.powerr}}</td>
                <th align="center">
                    <img src="uploads/{{x.pic1}}" alt="" style="margin-top: 4px;" width="40" height="40">
                </th>
                <th align="center">
                    <img src="uploads/{{x.pic2}}" alt="" style="margin-top: 4px;" width="40" height="40">
                </th>
            </tr>
        </table>
    </center>
</body>

</html>
