<?php
include_once("mysql-connection.php");
$medname=$_GET["medname"];
$uid=$_GET["uid"];
$rid=$_GET["rid"];
$query="select * from medicines where medname='$medname' and uid='$uid' and rid='$rid'";
$table=mysqli_query($dbcon,$query);
$ary=array();
while($row=mysqli_fetch_array($table))
{
	$ary[]=$row;
}
echo json_encode($ary);
?>
