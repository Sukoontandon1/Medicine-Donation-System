<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <!-- Required meta tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="CSS/bootstrapmy.css">
    <!-- Optional JavaScript; choose one of the two! -->
    <script src="JS/Jquery.js"></script>
    <script src="JS/Bootstrapmy.bundle.min.js"></script>
    <title>Document</title>
    <script>
        $(document).ready(function() {
            $("#email").blur(function() {
                var email = $("#email").val();
                var call = "ajax-chk-email.php?email=" + email;
                $.get(call, function(response) {
                    $("#chkemail").html(response);
                });
            });
            $("#signupbtn").click(function() {
                var email = $("#email").val();
                var pwd = $("#pwd").val();
                var mob = $("#mob").val();
                var category = $("#category").val();
                $.ajax({
                    type: 'GET',
                    url: 'ajax-signup.php',
                    data: {
                        email: email,
                        pwd: pwd,
                        mob: mob,
                        category: category
                    },
                    success: function(response) {
                        $("#saved").html(response);
                    }
                });
            });
            $("#signinbtn").click(function() {
                var email1 = $("#email1").val();
                var pwd1 = $("#pwd1").val();
                var call = "ajax-signin.php?email1=" + email1 + "&pwd1=" + pwd1;
                $.get(call, function(response) {
                    if (response.trim() == "Invalid ID or Password")
                        $("#saved1").html(response);
                    else if (response.trim() == "Provider")
                        window.open("dash-provider.php");
                    else
                        window.open("dash-needy.php");
                });
            });
        });

    </script>
</head>

<body style="background-color: #f0f0f0;">
    <?php
    include_once("header.php");
    ?>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #f0f0f0;margin-top: 20px;">
        <div class="container-fluid">
            <form class="d-flex" style="margin-left: 880px;">
                <div class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#SignupWin">Sign&nbsp;Up</div>
                <div class="btn btn-outline-success offset-2" style="margin-left: 21px;" data-bs-toggle="modal" data-bs-target="#SigninWin">Login</div>
                <a href="dash-admin.php">
                    <div class="btn btn-outline-success offset-2" style="margin-left: 21px;">Admin&nbsp;Dashboard</div>
                </a>
                <a href="#developers">
                    <div class="btn btn-outline-success offset-2" style="margin-left: 21px;">Developed&nbsp;By</div>
                </a>
                <a href="#reachUs">
                    <div class="btn btn-outline-success offset-2" style="margin-left: 21px;">Reach&nbsp;Us</div>
                </a>
            </form>
        </div>
    </nav>
    <div id="carouselExampleCaptions" class="carousel slide" style="padding: 100px;padding-top: 20px;" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="Pics/medicine1.jpg" style="height: 600px;" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                </div>
            </div>
            <div class="carousel-item">
                <img src="Pics/medicine8.jpg" style="height: 600px;" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                </div>
            </div>
            <div class="carousel-item">
                <img src="Pics/medicine3.jpg" style="height: 600px;" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <div style="padding-bottom: 30px;padding-top: 30px;">
        <div class="bg-warning text-light" style="margin: auto;padding: 15px;text-align: center;">
            <b>OUR SERVICES</b>
        </div>
    </div>
    <div class="card" style="width: 18rem;margin-top: 50px;margin-bottom: 50px;margin-left: 260px;float: left;align: center;">
        <div class="card-body">
            <div style="height: 143px;padding: 5px;text-align: center;">
                <img src="Pics/needy.jpg" width="100" height="100">
            </div>
            <div class="bg-success" style="border-radius: 5px;height: 30px;cursor: pointer;">
                <center><a class="card-link" style="text-decoration: none;color: white;padding-top: 10px;">Help Needy</a></center>
            </div>
        </div>
    </div>
    <div class="card" style="width: 18rem;margin-top: 50px;margin-bottom: 50px;margin-left: 60px;float: left">
        <div class="card-body">
            <div style="height: 143px;padding: 5px;text-align: center;">
                <img src="Pics/donate.png" width="200" height="100">
            </div>
            <div class="bg-success" style="border-radius: 5px;height: 30px;">
                <center>
                    <div class="card-link text-white" data-bs-target="" data-bs-toggle="modal" style="cursor: pointer;padding-top: 1.5px;">Donate Medicines</div>
                </center>
            </div>
        </div>
    </div>
    <div class="card" style="width: 18rem;margin-top: 50px;margin-bottom: 50px;margin-left: 60px;float: left">
        <div class="card-body">
            <div style="height: 143px;padding: 5px;text-align: center;">
                <img src="Pics/medicines.jpg" width="150" height="100">
            </div>
            <div class="bg-success" style="border-radius: 5px;height: 30px;">
                <center>
                    <div class="card-link text-white" data-bs-target="" data-bs-toggle="modal" style="cursor: pointer;padding-top: 1.5px;">Get Free Medicines</div>
                </center>
            </div>
        </div>
    </div>
    <div style="padding-bottom: 30px;padding-top: 30px;margin-top: 300px;">
        <div id="developers" class="bg-warning text-light" style="margin: auto;padding: 15px;text-align: center;">
            <b>ABOUT DEVELOPERS</b>
        </div>
    </div>
    <div class="card" style="width: 28rem;height: 28rem;margin-top: 50px;margin-bottom: 50px;margin-left: 215px;float: left">
        <div class="card-body">
            <div class="bg-success" style="border-radius: 5px;height: 30px;">
                <center>
                    <div class="card-link text-white" data-bs-target="" data-bs-toggle="modal" style="cursor: pointer;padding-top: 1.5px;">Under The Guidance Of: </div>
                </center>
            </div>
            <div style="height: 143px;padding: 5px;text-align: center;margin-top: 40px;">
                <img src="Pics/sir.jpg" style="border-radius: 50%;" width="250" height="250">
            </div>
            <div class="bg-success" style="border-radius: 5px;height: 30px;margin-top: 150px;">
                <center>
                    <div class="card-link text-white" data-bs-target="" data-bs-toggle="modal" style="cursor: pointer;padding-top: 1.5px;">Rajesh K. Bansal (MCA,SCJP,MCP)</div>
                </center>
            </div>
        </div>
    </div>
    <div class="card" style="width: 28rem;height: 28rem;margin-top: 50px;margin-bottom: 50px;margin-left: 200px;float: left">
        <div class="card-body">
            <div class="bg-success" style="border-radius: 5px;height: 30px;">
                <center>
                    <div class="card-link text-white" data-bs-target="" data-bs-toggle="modal" style="cursor: pointer;padding-top: 1.5px;">Developed By: </div>
                </center>
            </div>
            <div style="height: 143px;padding: 5px;text-align: center;margin-top: 40px;">
                <img src="Pics/sukoon.jpg" style="border-radius: 50%;" width="250" height="250">
            </div>
            <div class="bg-success" style="border-radius: 5px;height: 30px;margin-top: 150px;">
                <center>
                    <div class="card-link text-white" data-bs-target="" data-bs-toggle="modal" style="cursor: pointer;padding-top: 1.5px;">Sukoon Tandon</div>
                </center>
            </div>
        </div>
    </div>
    <div class="modal fade" id="SignupWin" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title" id="exampleModalLabel">Sign Up Window</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Email address</label>
                            <input type="email" class="form-control" name="email" id="email" required aria-describedby="emailHelp">
                            <div id="" class="form-text">
                                <span id="chkemail" class="form-text"></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Password</label>
                            <input type="password" class="form-control" required name="pwd" id="pwd">
                            <div id="" class="form-text">
                                <span id="" class="form-text"></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputMobile1" class="form-label">Mobile</label>
                            <input type="number_format" class="form-control" required name="mob" id="mob">
                            <div id="" class="form-text">
                                <span id="" class="form-text"></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputCategory1" class="form-label">Category</label>
                            <select name="category" id="category" class="form-select">
                                <option value="Provider" class="form-control">
                                    Provider
                                </option>
                                <option value="Needy" class="form-control">
                                    Needy
                                </option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer mb-3">
                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" value="Signup" id="signupbtn" name="btn">Signup</button>
                </div>
                <center>
                    <div class="mb-3"><span id="saved"></span></div>
                </center>
            </div>
        </div>
    </div>
    <form method="post" action="login.php">
        <div class="modal fade" id="SigninWin" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title" id="exampleModalLabel">Sign In Window</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Email address</label>
                            <input type="email" class="form-control" id="email1" required name="email1" aria-describedby="emailHelp">
                            <div id="" class="form-text">
                                <span id="" class="form-text"></span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Password</label>
                            <input type="password" class="form-control" required name="pwd1" id="pwd1">
                            <div id="" class="form-text">
                                <span id="" class="form-text"></span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer mb-3">
                        <button type="button" class="btn btn-success" data-bs-dismiss="modal">Close</button>
                        <div type="submit" class="btn btn-success" value="Signin" id="signinbtn" name="btn">Signin</div>
                    </div>
                    <center>
                        <div class="mb-3"><span id="saved1"></span></div>
                    </center>
                </div>
            </div>
        </div>
    </form>
    <div style="padding-bottom: 30px;padding-top: 30px;margin-top: 550px;">
        <div id="reachUs" class="bg-warning text-light" style="margin: auto;padding: 15px;text-align: center;">
            <b>REACH US</b>
        </div>
    </div>
    <center>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4876.0440219024795!2d74.9506104816838!3d30.211863969807116!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391732a4f07278a9%3A0x4a0d6293513f98ce!2sBanglore%20Computer%20Education%20(C%20C%2B%2B%20Android%20J2EE%20PHP%20Python%20AngularJs%20Spring%20Java%20Training%20Institute)!5e0!3m2!1sen!2sin!4v1611038927129!5m2!1sen!2sin" width="600" height="350" frameborder="2" style="border:0;width: 450px;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        <div class="" style="height: 30px;width: 100%;border-radius: 1px;margin-top: 50px;float: left;margin-left: -110px;"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#169;<span style="font-size: 15px;">2021</span>
        </div>
    </center>
</body>

</html>
