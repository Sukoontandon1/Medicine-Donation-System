<?php
include_once("mysql-connection.php");
$med=$_GET["med"];
$query="select distinct(city) from medicines where medname='$med'";
$table=mysqli_query($dbcon,$query);
$ary=array();
while($row=mysqli_fetch_array($table))
{
	$ary[]=$row;
}
echo json_encode($ary);
?>