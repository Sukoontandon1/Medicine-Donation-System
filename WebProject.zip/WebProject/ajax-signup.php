<?php
    include_once("mysql-connection.php");
    $email=$_GET["email"];
    $mob=$_GET["mob"];
    $pwd=$_GET["pwd"];
    $category=$_GET["category"];
    if($email==""||$mob==""||$pwd==""){
        echo "Fill In All The Fields";
        return;
    }
    $query="insert into users values('$email','$pwd','$mob','$category',CURRENT_DATE(),'1')";
    mysqli_query($dbcon,$query);
    if (mysqli_error($dbcon)=="")
        echo "Signed Up Successfully";
    else
        echo "User ID Already Taken";
?>
