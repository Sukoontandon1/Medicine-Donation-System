<?php
include_once("mysql-connection.php");
    $email=$_GET["email"];
    $query="update users set status=1 where email='$email'";
    mysqli_query($dbcon,$query);
?>
