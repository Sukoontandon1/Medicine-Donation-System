<?php
include_once("mysql-connection.php");
$uid=$_GET["uid"];
$query="select * from profiles";
$table=mysqli_query($dbcon,$query);
$ary=array();
while($row=mysqli_fetch_array($table))
{
	$ary[]=$row;
}
echo json_encode($ary);
?>