<?php
    $dbcon=mysqli_connect("localhost","root","","webproject");
?>